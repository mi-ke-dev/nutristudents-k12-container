<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateIngredients20211203Table extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('ingredients_20211203', function (Blueprint $table) {
            $table->uuid('id')->default('public.uuid_generate_v4()')->primary();
            $table->string('ns_ingredient')->nullable();
            $table->string('name');
            $table->string('category')->nullable();
            $table->uuid('component_id')->nullable();
            $table->uuid('prefer_product_id')->nullable();
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('ingredients_20211203');
    }
}
