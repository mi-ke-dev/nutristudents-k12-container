<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

class UpdateCategoryToRecipesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('recipes', function (Blueprint $table) {
            $table->string('category')->default('Entree')->change();
        });
        // DB::statement("ALTER TABLE recipes MODIFY category ENUM('Entree', 'Meat', 'Grain', 'Side', 'Vegetable', 'Fruit', 'Milk', 'Sauce') DEFAULT 'Entree'");
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('recipes', function (Blueprint $table) {
            
        });
    }
}
