<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddUsdaComponentFieldsToIngredientRecipeTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('ingredient_recipe', function (Blueprint $table) {
            $table->float('amount')->default(0)->after('recipe_id');
            $table->uuid('amount_uom_id')->nullable()->after('amount');
            $table->float('usda_componenent_meat')->default(0)->after('amount_uom_id');
            $table->float('usda_componenent_grain')->default(0)->after('usda_componenent_meat');
            $table->float('usda_componenent_fruit')->default(0)->after('usda_componenent_grain');
            $table->float('usda_componenent_milk')->default(0)->after('usda_componenent_fruit');
            $table->float('usda_componenent_veg')->default(0)->after('usda_componenent_milk');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('ingredient_recipe', function (Blueprint $table) {
            //
        });
    }
}
