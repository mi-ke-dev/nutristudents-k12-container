<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddFieldsToProductsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('products', function (Blueprint $table) {
            $table->string('gtin_number', 191)->nullable();
            $table->integer('pct_yield')->nullable();
            $table->integer('sort')->nullable();
            $table->boolean('is_commodity')->nullable();
            $table->boolean('is_kosher')->nullable();
            $table->boolean('can_use_for_ingredient')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('products', function (Blueprint $table) {
            $table->dropColumn('gtin_number');
            $table->dropColumn('pct_yield');
            $table->dropColumn('sort');
            $table->dropColumn('is_commodity');
            $table->dropColumn('is_kosher');
            $table->dropColumn('can_use_for_ingredient');
        });
    }
}
