<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddColumnOverrideToMenuCycleDayOptionComponentsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('menu_cycle_day_option_components', function (Blueprint $table) {
            $table->boolean('is_override')->default(false); 
            $table->text('total_val_override')->nullable(); 
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('menu_cycle_day_option_components', function (Blueprint $table) {
            //
        });
    }
}
