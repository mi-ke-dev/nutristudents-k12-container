<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddFieldsToGuidelinesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('guidelines', function (Blueprint $table) {
            
            $table->integer('user_id')->nullable();
            
            //Weekly Min Component Information
            $table->float('weekly_min_usda_componenent_serving_meat')->default(0);
            $table->float('weekly_min_usda_componenent_serving_grain')->default(0);
            $table->float('weekly_min_usda_componenent_serving_fruit')->default(0);
            $table->float('weekly_min_usda_componenent_serving_milk')->default(0);
            $table->float('weekly_min_usda_componenent_serving_veg')->default(0);
            $table->float('weekly_min_usda_componenent_serving_vegleg')->default(0);
            $table->float('weekly_min_usda_componenent_serving_vegred')->default(0);
            $table->float('weekly_min_usda_componenent_serving_veggrn')->default(0);
            $table->float('weekly_min_usda_componenent_serving_vegstar')->default(0);
            $table->float('weekly_min_usda_componenent_serving_vegothr')->default(0);

            //Nutrition Facts
            $table->float('weekly_min_nutrition_facts_calories')->default(0);
            $table->float('weekly_min_nutrition_facts_calfat')->default(0);
            $table->float('weekly_min_nutrition_facts_totalfat')->default(0);
            $table->float('weekly_min_nutrition_facts_satfat')->default(0);
            $table->float('weekly_min_nutrition_facts_transfat')->default(0);
            $table->float('weekly_min_nutrition_facts_polysatfat')->default(0);
            $table->float('weekly_min_nutrition_facts_monosatfat')->default(0);
            $table->float('weekly_min_nutrition_facts_cholesterol')->default(0);
            $table->float('weekly_min_nutrition_facts_sodium')->default(0);
            $table->float('weekly_min_nutrition_facts_potassium')->default(0);
            $table->float('weekly_min_nutrition_facts_carbs')->default(0);
            $table->float('weekly_min_nutrition_facts_fiber')->default(0);
            $table->float('weekly_min_nutrition_facts_sugar')->default(0);
            $table->float('weekly_min_nutrition_facts_protein')->default(0);
            $table->float('weekly_min_nutrition_facts_vitamina')->default(0);
            $table->float('weekly_min_nutrition_facts_vitaminb6')->default(0);
            $table->float('weekly_min_nutrition_facts_vitaminb12')->default(0);
            $table->float('weekly_min_nutrition_facts_vitaminc')->default(0);
            $table->float('weekly_min_nutrition_facts_vitamind')->default(0);
            $table->float('weekly_min_nutrition_facts_vitamine')->default(0);
            $table->float('weekly_min_nutrition_facts_calcium')->default(0);
            $table->float('weekly_min_nutrition_facts_iron')->default(0);
            $table->float('weekly_min_nutrition_facts_magnesium')->default(0);
            $table->float('weekly_min_nutrition_facts_coblamin')->default(0);
            $table->float('weekly_min_nutrition_facts_thiamin')->default(0);
            $table->float('weekly_min_nutrition_facts_riboflavin')->default(0);
            $table->float('weekly_min_nutrition_facts_niacin')->default(0);
            $table->float('weekly_min_nutrition_facts_zinc')->default(0);
            $table->float('weekly_min_nutrition_facts_water')->default(0);
            $table->float('weekly_min_nutrition_facts_ash')->default(0);


            // Daily Min Component Information
            $table->float('daily_min_usda_componenent_serving_meat')->default(0);
            $table->float('daily_min_usda_componenent_serving_grain')->default(0);
            $table->float('daily_min_usda_componenent_serving_fruit')->default(0);
            $table->float('daily_min_usda_componenent_serving_milk')->default(0);
            $table->float('daily_min_usda_componenent_serving_veg')->default(0);
            $table->float('daily_min_usda_componenent_serving_vegleg')->default(0);
            $table->float('daily_min_usda_componenent_serving_vegred')->default(0);
            $table->float('daily_min_usda_componenent_serving_veggrn')->default(0);
            $table->float('daily_min_usda_componenent_serving_vegstar')->default(0);
            $table->float('daily_min_usda_componenent_serving_vegothr')->default(0);


            // Nutrition Facts
            $table->float('daily_min_nutrition_facts_calories')->default(0);
            $table->float('daily_min_nutrition_facts_calfat')->default(0);
            $table->float('daily_min_nutrition_facts_totalfat')->default(0);
            $table->float('daily_min_nutrition_facts_satfat')->default(0);
            $table->float('daily_min_nutrition_facts_transfat')->default(0);
            $table->float('daily_min_nutrition_facts_polysatfat')->default(0);
            $table->float('daily_min_nutrition_facts_monosatfat')->default(0);
            $table->float('daily_min_nutrition_facts_cholesterol')->default(0);
            $table->float('daily_min_nutrition_facts_sodium')->default(0);
            $table->float('daily_min_nutrition_facts_potassium')->default(0);
            $table->float('daily_min_nutrition_facts_carbs')->default(0);
            $table->float('daily_min_nutrition_facts_fiber')->default(0);
            $table->float('daily_min_nutrition_facts_sugar')->default(0);
            $table->float('daily_min_nutrition_facts_protein')->default(0);
            $table->float('daily_min_nutrition_facts_vitamina')->default(0);
            $table->float('daily_min_nutrition_facts_vitaminb6')->default(0);
            $table->float('daily_min_nutrition_facts_vitaminb12')->default(0);
            $table->float('daily_min_nutrition_facts_vitaminc')->default(0);
            $table->float('daily_min_nutrition_facts_vitamind')->default(0);
            $table->float('daily_min_nutrition_facts_vitamine')->default(0);
            $table->float('daily_min_nutrition_facts_calcium')->default(0);
            $table->float('daily_min_nutrition_facts_iron')->default(0);
            $table->float('daily_min_nutrition_facts_magnesium')->default(0);
            $table->float('daily_min_nutrition_facts_coblamin')->default(0);
            $table->float('daily_min_nutrition_facts_thiamin')->default(0);
            $table->float('daily_min_nutrition_facts_riboflavin')->default(0);
            $table->float('daily_min_nutrition_facts_niacin')->default(0);
            $table->float('daily_min_nutrition_facts_zinc')->default(0);
            $table->float('daily_min_nutrition_facts_water')->default(0);
            $table->float('daily_min_nutrition_facts_ash')->default(0);



            // Weekly Max Component Information
            $table->float('weekly_max_usda_componenent_serving_meat')->default(0);
            $table->float('weekly_max_usda_componenent_serving_grain')->default(0);
            $table->float('weekly_max_usda_componenent_serving_fruit')->default(0);
            $table->float('weekly_max_usda_componenent_serving_milk')->default(0);
            $table->float('weekly_max_usda_componenent_serving_veg')->default(0);
            $table->float('weekly_max_usda_componenent_serving_vegleg')->default(0);
            $table->float('weekly_max_usda_componenent_serving_vegred')->default(0);
            $table->float('weekly_max_usda_componenent_serving_veggrn')->default(0);
            $table->float('weekly_max_usda_componenent_serving_vegstar')->default(0);
            $table->float('weekly_max_usda_componenent_serving_vegothr')->default(0);

            // Nutrition Facts
            $table->float('weekly_max_nutrition_facts_calories')->default(0);
            $table->float('weekly_max_nutrition_facts_calfat')->default(0);
            $table->float('weekly_max_nutrition_facts_totalfat')->default(0);
            $table->float('weekly_max_nutrition_facts_satfat')->default(0);
            $table->float('weekly_max_nutrition_facts_transfat')->default(0);
            $table->float('weekly_max_nutrition_facts_polysatfat')->default(0);
            $table->float('weekly_max_nutrition_facts_monosatfat')->default(0);
            $table->float('weekly_max_nutrition_facts_cholesterol')->default(0);
            $table->float('weekly_max_nutrition_facts_sodium')->default(0);
            $table->float('weekly_max_nutrition_facts_potassium')->default(0);
            $table->float('weekly_max_nutrition_facts_carbs')->default(0);
            $table->float('weekly_max_nutrition_facts_fiber')->default(0);
            $table->float('weekly_max_nutrition_facts_sugar')->default(0);
            $table->float('weekly_max_nutrition_facts_protein')->default(0);
            $table->float('weekly_max_nutrition_facts_vitamina')->default(0);
            $table->float('weekly_max_nutrition_facts_vitaminb6')->default(0);
            $table->float('weekly_max_nutrition_facts_vitaminb12')->default(0);
            $table->float('weekly_max_nutrition_facts_vitaminc')->default(0);
            $table->float('weekly_max_nutrition_facts_vitamind')->default(0);
            $table->float('weekly_max_nutrition_facts_vitamine')->default(0);
            $table->float('weekly_max_nutrition_facts_calcium')->default(0);
            $table->float('weekly_max_nutrition_facts_iron')->default(0);
            $table->float('weekly_max_nutrition_facts_magnesium')->default(0);
            $table->float('weekly_max_nutrition_facts_coblamin')->default(0);
            $table->float('weekly_max_nutrition_facts_thiamin')->default(0);
            $table->float('weekly_max_nutrition_facts_riboflavin')->default(0);
            $table->float('weekly_max_nutrition_facts_niacin')->default(0);
            $table->float('weekly_max_nutrition_facts_zinc')->default(0);
            $table->float('weekly_max_nutrition_facts_water')->default(0);
            $table->float('weekly_max_nutrition_facts_ash')->default(0);


            // Daily Max Component Information
            $table->float('daily_max_usda_componenent_serving_meat')->default(0);
            $table->float('daily_max_usda_componenent_serving_grain')->default(0);
            $table->float('daily_max_usda_componenent_serving_fruit')->default(0);
            $table->float('daily_max_usda_componenent_serving_milk')->default(0);
            $table->float('daily_max_usda_componenent_serving_veg')->default(0);
            $table->float('daily_max_usda_componenent_serving_vegleg')->default(0);
            $table->float('daily_max_usda_componenent_serving_vegred')->default(0);
            $table->float('daily_max_usda_componenent_serving_veggrn')->default(0);
            $table->float('daily_max_usda_componenent_serving_vegstar')->default(0);
            $table->float('daily_max_usda_componenent_serving_vegothr')->default(0);


            // Nutrition Facts
            $table->float('daily_max_nutrition_facts_calories')->default(0);
            $table->float('daily_max_nutrition_facts_calfat')->default(0);
            $table->float('daily_max_nutrition_facts_totalfat')->default(0);
            $table->float('daily_max_nutrition_facts_satfat')->default(0);
            $table->float('daily_max_nutrition_facts_transfat')->default(0);
            $table->float('daily_max_nutrition_facts_polysatfat')->default(0);
            $table->float('daily_max_nutrition_facts_monosatfat')->default(0);
            $table->float('daily_max_nutrition_facts_cholesterol')->default(0);
            $table->float('daily_max_nutrition_facts_sodium')->default(0);
            $table->float('daily_max_nutrition_facts_potassium')->default(0);
            $table->float('daily_max_nutrition_facts_carbs')->default(0);
            $table->float('daily_max_nutrition_facts_fiber')->default(0);
            $table->float('daily_max_nutrition_facts_sugar')->default(0);
            $table->float('daily_max_nutrition_facts_protein')->default(0);
            $table->float('daily_max_nutrition_facts_vitamina')->default(0);
            $table->float('daily_max_nutrition_facts_vitaminb6')->default(0);
            $table->float('daily_max_nutrition_facts_vitaminb12')->default(0);
            $table->float('daily_max_nutrition_facts_vitaminc')->default(0);
            $table->float('daily_max_nutrition_facts_vitamind')->default(0);
            $table->float('daily_max_nutrition_facts_vitamine')->default(0);
            $table->float('daily_max_nutrition_facts_calcium')->default(0);
            $table->float('daily_max_nutrition_facts_iron')->default(0);
            $table->float('daily_max_nutrition_facts_magnesium')->default(0);
            $table->float('daily_max_nutrition_facts_coblamin')->default(0);
            $table->float('daily_max_nutrition_facts_thiamin')->default(0);
            $table->float('daily_max_nutrition_facts_riboflavin')->default(0);
            $table->float('daily_max_nutrition_facts_niacin')->default(0);
            $table->float('daily_max_nutrition_facts_zinc')->default(0);
            $table->float('daily_max_nutrition_facts_water')->default(0);
            $table->float('daily_max_nutrition_facts_ash')->default(0);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('guidelines', function (Blueprint $table) {
            //
        });
    }
}
