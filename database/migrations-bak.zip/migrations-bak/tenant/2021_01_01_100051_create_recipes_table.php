<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

class CreateRecipesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {

        Schema::create('recipes', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->string('name');
            $table->string('ns_recipe')->nullable();
            $table->enum('category', ['Entree', 'Side', 'Sauce'])->default('Entree');
            $table->integer('portion');
            $table->integer('serving_size');
            $table->mediumText('cooking_instructions')->nullable();
            $table->string('photo_store_path')->nullable();
            $table->nullableTimestamps();
            $table->softDeletes();

        });

    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('recipes');
    }
}
