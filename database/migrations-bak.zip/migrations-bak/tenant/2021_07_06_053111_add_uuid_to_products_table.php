<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddUuidToProductsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('products', function (Blueprint $table) {
            $table->string('case_volume_uom_id')->nullable()->after('case_volume');
            $table->float('sub_case_volume')->nullable()->after('case_volume_uom_id');
            $table->string('serving_measurement_unit_uom_id')->nullable()->after('serving_measurement_unit');

            $table->string('nutrition_facts_volume_uom_id')->nullable()->after('nutrition_facts_volume');  
            $table->string('nutrition_facts_unit_uom_id')->nullable()->after('nutrition_facts_unit');  
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('products', function (Blueprint $table) {
            //
        });
    }
}
