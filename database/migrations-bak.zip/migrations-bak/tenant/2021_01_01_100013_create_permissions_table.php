<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

class CreatePermissionsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {

        Schema::create('permissions', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->uuid('user_id');
            $table->uuidMorphs('modelable'); // applies to User to Group
            $table->uuidMorphs('permissionable'); // applies to Site or Group
            $table->boolean('is_admin')->default(false);
            $table->boolean('menu_edit')->default(false);
            $table->boolean('order_edit')->default(false);
            $table->boolean('student_counts')->default(false);
            $table->boolean('view')->default(false);
            $table->nullableTimestamps();
            $table->softDeletes();

        });


    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('permissions');
    }
}
