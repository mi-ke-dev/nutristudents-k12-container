<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class NullableFieldsOnProductsTabe extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {

        Schema::table('products', function (Blueprint $table) {
            $table->float('usda_componenent_serving_meat')->nullable()->default(null)->change();
            $table->float('usda_componenent_serving_grain')->nullable()->default(null)->change();
            $table->float('usda_componenent_serving_fruit')->nullable()->default(null)->change();
            $table->float('usda_componenent_serving_veg')->nullable()->default(null)->change();
            $table->float('usda_componenent_serving_vegleg')->nullable()->default(null)->change();
            $table->float('usda_componenent_serving_vegred')->nullable()->default(null)->change();
            $table->float('usda_componenent_serving_veggrn')->nullable()->default(null)->change();
            $table->float('usda_componenent_serving_vegstar')->nullable()->default(null)->change();
            $table->float('usda_componenent_serving_vegothr')->nullable()->default(null)->change();
            $table->float('usda_componenent_serving_milk')->nullable()->default(null)->change();


            // Nutrition Facts
            $table->float('nutrition_facts_weight')->nullable()->change();
            $table->uuid('nutrition_facts_weight_uom_id')->nullable()->change();

            $table->float('nutrition_facts_volume')->nullable()->change();
            $table->uuid('nutrition_facts_uom_id')->nullable()->change();

            $table->float('nutrition_facts_unit')->nullable()->change();

            $table->float('nutrition_facts_calories')->nullable()->default(null)->change();
            $table->float('nutrition_facts_calfat')->nullable()->default(null)->change();
            $table->float('nutrition_facts_totalfat')->nullable()->default(null)->change();
            $table->float('nutrition_facts_satfat')->nullable()->default(null)->change();
            $table->float('nutrition_facts_transfat')->nullable()->default(null)->change();
            $table->float('nutrition_facts_polysatfat')->nullable()->default(null)->change();
            $table->float('nutrition_facts_monosatfat')->nullable()->default(null)->change();
            $table->float('nutrition_facts_cholesterol')->nullable()->default(null)->change();
            $table->float('nutrition_facts_sodium')->nullable()->default(null)->change();
            $table->float('nutrition_facts_potassium')->nullable()->default(null)->change();
            $table->float('nutrition_facts_carbs')->nullable()->default(null)->change();
            $table->float('nutrition_facts_fiber')->nullable()->default(null)->change();
            $table->float('nutrition_facts_sugar')->nullable()->default(null)->change();
            $table->float('nutrition_facts_protein')->nullable()->default(null)->change();
            $table->float('nutrition_facts_vitamina')->nullable()->default(null)->change();
            $table->float('nutrition_facts_vitaminb6')->nullable()->default(null)->change();
            $table->float('nutrition_facts_vitaminb12')->nullable()->default(null)->change();
            $table->float('nutrition_facts_vitaminc')->nullable()->default(null)->change();
            $table->float('nutrition_facts_vitamind')->nullable()->default(null)->change();
            $table->float('nutrition_facts_vitamine')->nullable()->default(null)->change();
            $table->float('nutrition_facts_calcium')->nullable()->default(null)->change();
            $table->float('nutrition_facts_iron')->nullable()->default(null)->change();
            $table->float('nutrition_facts_magnesium')->nullable()->default(null)->change();
            $table->float('nutrition_facts_coblamin')->nullable()->default(null)->change();
            $table->float('nutrition_facts_thiamin')->nullable()->default(null)->change();
            $table->float('nutrition_facts_riboflavin')->nullable()->default(null)->change();
            $table->float('nutrition_facts_niacin')->nullable()->default(null)->change();
            $table->float('nutrition_facts_zinc')->nullable()->default(null)->change();
            $table->float('nutrition_facts_water')->nullable()->default(null)->change();
            $table->float('nutrition_facts_ash')->nullable()->default(null)->change();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
