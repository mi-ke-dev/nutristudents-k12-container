<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddOverrideColsToIngRecipeTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('ingredient_recipe', function (Blueprint $table) {
            $table->float('usda_componenent_meat_override')->nullable()->default(null)->after('usda_componenent_vegothr');
            $table->float('usda_componenent_grain_override')->nullable()->default(null)->after('usda_componenent_meat_override');
            $table->float('usda_componenent_fruit_override')->nullable()->default(null)->after('usda_componenent_grain_override');
            $table->float('usda_componenent_milk_override')->nullable()->default(null)->after('usda_componenent_fruit_override');
            $table->float('usda_componenent_veg_override')->nullable()->default(null)->after('usda_componenent_milk_override');
            $table->float('usda_componenent_veggrn_override')->nullable()->default(null)->after('usda_componenent_veg_override');
            $table->float('usda_componenent_vegred_override')->nullable()->default(null)->after('usda_componenent_veggrn_override');
            $table->float('usda_componenent_vegleg_override')->nullable()->default(null)->after('usda_componenent_vegred_override');
            $table->float('usda_componenent_vegstar_override')->nullable()->default(null)->after('usda_componenent_vegleg_override');
            $table->float('usda_componenent_vegothr_override')->nullable()->default(null)->after('usda_componenent_vegstar_override');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('ingredient_recipe', function (Blueprint $table) {
            //
        });
    }
}
