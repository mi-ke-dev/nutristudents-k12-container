<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class NullableFieldsOnIngredientRecipeTabe extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {

        Schema::table('ingredient_recipe', function (Blueprint $table) {
            $table->float('usda_componenent_meat')->nullable()->default(null)->change();
            $table->float('usda_componenent_grain')->nullable()->default(null)->change();
            $table->float('usda_componenent_fruit')->nullable()->default(null)->change();
            $table->float('usda_componenent_milk')->nullable()->default(null)->change();
            $table->float('usda_componenent_veg')->nullable()->default(null)->change();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {

        Schema::table('ingredient_recipe', function (Blueprint $table) {
            $table->float('usda_componenent_meat')->change();
            $table->float('usda_componenent_grain')->change();
            $table->float('usda_componenent_fruit')->change();
            $table->float('usda_componenent_milk')->change();
            $table->float('usda_componenent_veg')->change();
        });
    }
}
