<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class UpdateColumnsToIngRecipeTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('ingredient_recipe', function (Blueprint $table) {
            $table->renameColumn('amount','recipe_amount');
            $table->renameColumn('amount_uom_id','recipe_amount_uom_id');
            
            $table->float('serving_amount')->default(0);
            $table->uuid('serving_amount_uom_id')->nullable()->after('serving_amount');
            $table->float('usda_componenent_veggrn')->nullable()->default(null)->after('usda_componenent_veg');
            $table->float('usda_componenent_vegred')->nullable()->default(null)->after('usda_componenent_veggrn');
            $table->float('usda_componenent_vegleg')->nullable()->default(null)->after('usda_componenent_vegred');
            $table->float('usda_componenent_vegstar')->nullable()->default(null)->after('usda_componenent_vegleg');
            $table->float('usda_componenent_vegothr')->nullable()->default(null)->after('usda_componenent_vegstar');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('ingredient_recipe', function (Blueprint $table) {
            //
        });
    }
}
