<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class UpdateGuidelinesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('guidelines', function (Blueprint $table) {
            //Weekly Min Component Information
            $table->float('weekly_min_usda_componenent_serving_meat')->nullable()->change();
            $table->float('weekly_min_usda_componenent_serving_grain')->nullable()->change();
            $table->float('weekly_min_usda_componenent_serving_fruit')->nullable()->change();
            $table->float('weekly_min_usda_componenent_serving_milk')->nullable()->change();
            $table->float('weekly_min_usda_componenent_serving_veg')->nullable()->change();
            $table->float('weekly_min_usda_componenent_serving_vegleg')->nullable()->change();
            $table->float('weekly_min_usda_componenent_serving_vegred')->nullable()->change();
            $table->float('weekly_min_usda_componenent_serving_veggrn')->nullable()->change();
            $table->float('weekly_min_usda_componenent_serving_vegstar')->nullable()->change();
            $table->float('weekly_min_usda_componenent_serving_vegothr')->nullable()->change();

            //Nutrition Facts
            $table->float('weekly_min_nutrition_facts_calories')->nullable()->change();
            $table->float('weekly_min_nutrition_facts_calfat')->nullable()->change();
            $table->float('weekly_min_nutrition_facts_totalfat')->nullable()->change();
            $table->float('weekly_min_nutrition_facts_satfat')->nullable()->change();
            $table->float('weekly_min_nutrition_facts_transfat')->nullable()->change();
            $table->float('weekly_min_nutrition_facts_polysatfat')->nullable()->change();
            $table->float('weekly_min_nutrition_facts_monosatfat')->nullable()->change();
            $table->float('weekly_min_nutrition_facts_cholesterol')->nullable()->change();
            $table->float('weekly_min_nutrition_facts_sodium')->nullable()->change();
            $table->float('weekly_min_nutrition_facts_potassium')->nullable()->change();
            $table->float('weekly_min_nutrition_facts_carbs')->nullable()->change();
            $table->float('weekly_min_nutrition_facts_fiber')->nullable()->change();
            $table->float('weekly_min_nutrition_facts_sugar')->nullable()->change();
            $table->float('weekly_min_nutrition_facts_protein')->nullable()->change();
            $table->float('weekly_min_nutrition_facts_vitamina')->nullable()->change();
            $table->float('weekly_min_nutrition_facts_vitaminb6')->nullable()->change();
            $table->float('weekly_min_nutrition_facts_vitaminb12')->nullable()->change();
            $table->float('weekly_min_nutrition_facts_vitaminc')->nullable()->change();
            $table->float('weekly_min_nutrition_facts_vitamind')->nullable()->change();
            $table->float('weekly_min_nutrition_facts_vitamine')->nullable()->change();
            $table->float('weekly_min_nutrition_facts_calcium')->nullable()->change();
            $table->float('weekly_min_nutrition_facts_iron')->nullable()->change();
            $table->float('weekly_min_nutrition_facts_magnesium')->nullable()->change();
            $table->float('weekly_min_nutrition_facts_coblamin')->nullable()->change();
            $table->float('weekly_min_nutrition_facts_thiamin')->nullable()->change();
            $table->float('weekly_min_nutrition_facts_riboflavin')->nullable()->change();
            $table->float('weekly_min_nutrition_facts_niacin')->nullable()->change();
            $table->float('weekly_min_nutrition_facts_zinc')->nullable()->change();
            $table->float('weekly_min_nutrition_facts_water')->nullable()->change();
            $table->float('weekly_min_nutrition_facts_ash')->nullable()->change();


            // Daily Min Component Information
            $table->float('daily_min_usda_componenent_serving_meat')->nullable()->change();
            $table->float('daily_min_usda_componenent_serving_grain')->nullable()->change();
            $table->float('daily_min_usda_componenent_serving_fruit')->nullable()->change();
            $table->float('daily_min_usda_componenent_serving_milk')->nullable()->change();
            $table->float('daily_min_usda_componenent_serving_veg')->nullable()->change();
            $table->float('daily_min_usda_componenent_serving_vegleg')->nullable()->change();
            $table->float('daily_min_usda_componenent_serving_vegred')->nullable()->change();
            $table->float('daily_min_usda_componenent_serving_veggrn')->nullable()->change();
            $table->float('daily_min_usda_componenent_serving_vegstar')->nullable()->change();
            $table->float('daily_min_usda_componenent_serving_vegothr')->nullable()->change();


            // Nutrition Facts
            $table->float('daily_min_nutrition_facts_calories')->nullable()->change();
            $table->float('daily_min_nutrition_facts_calfat')->nullable()->change();
            $table->float('daily_min_nutrition_facts_totalfat')->nullable()->change();
            $table->float('daily_min_nutrition_facts_satfat')->nullable()->change();
            $table->float('daily_min_nutrition_facts_transfat')->nullable()->change();
            $table->float('daily_min_nutrition_facts_polysatfat')->nullable()->change();
            $table->float('daily_min_nutrition_facts_monosatfat')->nullable()->change();
            $table->float('daily_min_nutrition_facts_cholesterol')->nullable()->change();
            $table->float('daily_min_nutrition_facts_sodium')->nullable()->change();
            $table->float('daily_min_nutrition_facts_potassium')->nullable()->change();
            $table->float('daily_min_nutrition_facts_carbs')->nullable()->change();
            $table->float('daily_min_nutrition_facts_fiber')->nullable()->change();
            $table->float('daily_min_nutrition_facts_sugar')->nullable()->change();
            $table->float('daily_min_nutrition_facts_protein')->nullable()->change();
            $table->float('daily_min_nutrition_facts_vitamina')->nullable()->change();
            $table->float('daily_min_nutrition_facts_vitaminb6')->nullable()->change();
            $table->float('daily_min_nutrition_facts_vitaminb12')->nullable()->change();
            $table->float('daily_min_nutrition_facts_vitaminc')->nullable()->change();
            $table->float('daily_min_nutrition_facts_vitamind')->nullable()->change();
            $table->float('daily_min_nutrition_facts_vitamine')->nullable()->change();
            $table->float('daily_min_nutrition_facts_calcium')->nullable()->change();
            $table->float('daily_min_nutrition_facts_iron')->nullable()->change();
            $table->float('daily_min_nutrition_facts_magnesium')->nullable()->change();
            $table->float('daily_min_nutrition_facts_coblamin')->nullable()->change();
            $table->float('daily_min_nutrition_facts_thiamin')->nullable()->change();
            $table->float('daily_min_nutrition_facts_riboflavin')->nullable()->change();
            $table->float('daily_min_nutrition_facts_niacin')->nullable()->change();
            $table->float('daily_min_nutrition_facts_zinc')->nullable()->change();
            $table->float('daily_min_nutrition_facts_water')->nullable()->change();
            $table->float('daily_min_nutrition_facts_ash')->nullable()->change();



            // Weekly Max Component Information
            $table->float('weekly_max_usda_componenent_serving_meat')->nullable()->change();
            $table->float('weekly_max_usda_componenent_serving_grain')->nullable()->change();
            $table->float('weekly_max_usda_componenent_serving_fruit')->nullable()->change();
            $table->float('weekly_max_usda_componenent_serving_milk')->nullable()->change();
            $table->float('weekly_max_usda_componenent_serving_veg')->nullable()->change();
            $table->float('weekly_max_usda_componenent_serving_vegleg')->nullable()->change();
            $table->float('weekly_max_usda_componenent_serving_vegred')->nullable()->change();
            $table->float('weekly_max_usda_componenent_serving_veggrn')->nullable()->change();
            $table->float('weekly_max_usda_componenent_serving_vegstar')->nullable()->change();
            $table->float('weekly_max_usda_componenent_serving_vegothr')->nullable()->change();

            // Nutrition Facts
            $table->float('weekly_max_nutrition_facts_calories')->nullable()->change();
            $table->float('weekly_max_nutrition_facts_calfat')->nullable()->change();
            $table->float('weekly_max_nutrition_facts_totalfat')->nullable()->change();
            $table->float('weekly_max_nutrition_facts_satfat')->nullable()->change();
            $table->float('weekly_max_nutrition_facts_transfat')->nullable()->change();
            $table->float('weekly_max_nutrition_facts_polysatfat')->nullable()->change();
            $table->float('weekly_max_nutrition_facts_monosatfat')->nullable()->change();
            $table->float('weekly_max_nutrition_facts_cholesterol')->nullable()->change();
            $table->float('weekly_max_nutrition_facts_sodium')->nullable()->change();
            $table->float('weekly_max_nutrition_facts_potassium')->nullable()->change();
            $table->float('weekly_max_nutrition_facts_carbs')->nullable()->change();
            $table->float('weekly_max_nutrition_facts_fiber')->nullable()->change();
            $table->float('weekly_max_nutrition_facts_sugar')->nullable()->change();
            $table->float('weekly_max_nutrition_facts_protein')->nullable()->change();
            $table->float('weekly_max_nutrition_facts_vitamina')->nullable()->change();
            $table->float('weekly_max_nutrition_facts_vitaminb6')->nullable()->change();
            $table->float('weekly_max_nutrition_facts_vitaminb12')->nullable()->change();
            $table->float('weekly_max_nutrition_facts_vitaminc')->nullable()->change();
            $table->float('weekly_max_nutrition_facts_vitamind')->nullable()->change();
            $table->float('weekly_max_nutrition_facts_vitamine')->nullable()->change();
            $table->float('weekly_max_nutrition_facts_calcium')->nullable()->change();
            $table->float('weekly_max_nutrition_facts_iron')->nullable()->change();
            $table->float('weekly_max_nutrition_facts_magnesium')->nullable()->change();
            $table->float('weekly_max_nutrition_facts_coblamin')->nullable()->change();
            $table->float('weekly_max_nutrition_facts_thiamin')->nullable()->change();
            $table->float('weekly_max_nutrition_facts_riboflavin')->nullable()->change();
            $table->float('weekly_max_nutrition_facts_niacin')->nullable()->change();
            $table->float('weekly_max_nutrition_facts_zinc')->nullable()->change();
            $table->float('weekly_max_nutrition_facts_water')->nullable()->change();
            $table->float('weekly_max_nutrition_facts_ash')->nullable()->change();


            // Daily Max Component Information
            $table->float('daily_max_usda_componenent_serving_meat')->nullable()->change();
            $table->float('daily_max_usda_componenent_serving_grain')->nullable()->change();
            $table->float('daily_max_usda_componenent_serving_fruit')->nullable()->change();
            $table->float('daily_max_usda_componenent_serving_milk')->nullable()->change();
            $table->float('daily_max_usda_componenent_serving_veg')->nullable()->change();
            $table->float('daily_max_usda_componenent_serving_vegleg')->nullable()->change();
            $table->float('daily_max_usda_componenent_serving_vegred')->nullable()->change();
            $table->float('daily_max_usda_componenent_serving_veggrn')->nullable()->change();
            $table->float('daily_max_usda_componenent_serving_vegstar')->nullable()->change();
            $table->float('daily_max_usda_componenent_serving_vegothr')->nullable()->change();


            // Nutrition Facts
            $table->float('daily_max_nutrition_facts_calories')->nullable()->change();
            $table->float('daily_max_nutrition_facts_calfat')->nullable()->change();
            $table->float('daily_max_nutrition_facts_totalfat')->nullable()->change();
            $table->float('daily_max_nutrition_facts_satfat')->nullable()->change();
            $table->float('daily_max_nutrition_facts_transfat')->nullable()->change();
            $table->float('daily_max_nutrition_facts_polysatfat')->nullable()->change();
            $table->float('daily_max_nutrition_facts_monosatfat')->nullable()->change();
            $table->float('daily_max_nutrition_facts_cholesterol')->nullable()->change();
            $table->float('daily_max_nutrition_facts_sodium')->nullable()->change();
            $table->float('daily_max_nutrition_facts_potassium')->nullable()->change();
            $table->float('daily_max_nutrition_facts_carbs')->nullable()->change();
            $table->float('daily_max_nutrition_facts_fiber')->nullable()->change();
            $table->float('daily_max_nutrition_facts_sugar')->nullable()->change();
            $table->float('daily_max_nutrition_facts_protein')->nullable()->change();
            $table->float('daily_max_nutrition_facts_vitamina')->nullable()->change();
            $table->float('daily_max_nutrition_facts_vitaminb6')->nullable()->change();
            $table->float('daily_max_nutrition_facts_vitaminb12')->nullable()->change();
            $table->float('daily_max_nutrition_facts_vitaminc')->nullable()->change();
            $table->float('daily_max_nutrition_facts_vitamind')->nullable()->change();
            $table->float('daily_max_nutrition_facts_vitamine')->nullable()->change();
            $table->float('daily_max_nutrition_facts_calcium')->nullable()->change();
            $table->float('daily_max_nutrition_facts_iron')->nullable()->change();
            $table->float('daily_max_nutrition_facts_magnesium')->nullable()->change();
            $table->float('daily_max_nutrition_facts_coblamin')->nullable()->change();
            $table->float('daily_max_nutrition_facts_thiamin')->nullable()->change();
            $table->float('daily_max_nutrition_facts_riboflavin')->nullable()->change();
            $table->float('daily_max_nutrition_facts_niacin')->nullable()->change();
            $table->float('daily_max_nutrition_facts_zinc')->nullable()->change();
            $table->float('daily_max_nutrition_facts_water')->nullable()->change();
            $table->float('daily_max_nutrition_facts_ash')->nullable()->change();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('guidelines', function (Blueprint $table) {
            //
        });
    }
}
