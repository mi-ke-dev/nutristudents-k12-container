<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

class CreateMenuCycleDayOptionComponentsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {

        Schema::create('menu_cycle_day_option_components', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->uuid('menu_cycle_day_option_id')->nullable();
            $table->uuid('recipe_id');
            $table->mediumText('cooking_instructions')->nullable();
            $table->json('exclude_from')->nullable();
            $table->boolean('smart_snack')->default(false);
            $table->integer('sort_order')->default(0);
            $table->nullableTimestamps();
            $table->softDeletes();

        });


    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('menu_cycle_day_option_components');
    }
}
