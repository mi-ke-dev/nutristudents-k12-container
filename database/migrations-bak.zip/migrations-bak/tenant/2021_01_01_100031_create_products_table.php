<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

class CreateProductsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {

        Schema::create('products', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->uuid('distributor_id')->nullable();
            $table->string('name');
            $table->string('manufacturer')->nullable();
            $table->string('manufacturer_sku')->nullable();

            // Primary Component
            $table->uuid('primary_component_id')->nullable();
            $table->uuid('primary_sub_component_id')->nullable();

            // Secondary components
            // See component_product table

            // Product Tags
            // See product_tag table

            // Case Information
            $table->float('case_weight')->nullable();
            $table->uuid('case_weight_uom_id')->nullable();

            $table->float('sub_case_weight')->nullable();
            $table->uuid('sub_case_weight_uom_id')->nullable();

            $table->float('case_volume')->nullable();
            $table->uuid('sub_case_volume_uom_id')->nullable();

            $table->integer('case_quantity')->nullable();
            $table->integer('sub_case_quantity')->nullable();

            // Measurement Information
            $table->float('serving_measurement_weight')->nullable();
            $table->uuid('serving_measurement_weight_uom_id')->nullable();

            $table->float('serving_measurement_volume')->nullable();
            $table->uuid('serving_measurement_volume_uom_id')->nullable();

            $table->float('serving_measurement_unit')->nullable();

            // Component Information
            $table->float('usda_componenent_serving_meat')->default(0);
            $table->float('usda_componenent_serving_grain')->default(0);
            $table->float('usda_componenent_serving_fruit')->default(0);
            $table->float('usda_componenent_serving_veg')->default(0);
            $table->float('usda_componenent_serving_vegleg')->default(0);
            $table->float('usda_componenent_serving_vegred')->default(0);
            $table->float('usda_componenent_serving_veggrn')->default(0);
            $table->float('usda_componenent_serving_vegstar')->default(0);
            $table->float('usda_componenent_serving_vegothr')->default(0);


            // Nutrition Facts
            $table->float('nutrition_facts_weight')->nullable();
            $table->uuid('nutrition_facts_weight_uom_id')->nullable();

            $table->float('nutrition_facts_volume')->nullable();
            $table->uuid('nutrition_facts_uom_id')->nullable();

            $table->float('nutrition_facts_unit')->nullable();

            $table->float('nutrition_facts_calories')->default(0);
            $table->float('nutrition_facts_calfat')->default(0);
            $table->float('nutrition_facts_totalfat')->default(0);
            $table->float('nutrition_facts_satfat')->default(0);
            $table->float('nutrition_facts_transfat')->default(0);
            $table->float('nutrition_facts_polysatfat')->default(0);
            $table->float('nutrition_facts_monosatfat')->default(0);
            $table->float('nutrition_facts_cholesterol')->default(0);
            $table->float('nutrition_facts_sodium')->default(0);
            $table->float('nutrition_facts_potassium')->default(0);
            $table->float('nutrition_facts_carbs')->default(0);
            $table->float('nutrition_facts_fiber')->default(0);
            $table->float('nutrition_facts_sugar')->default(0);
            $table->float('nutrition_facts_protein')->default(0);
            $table->float('nutrition_facts_vitamina')->default(0);
            $table->float('nutrition_facts_vitaminb6')->default(0);
            $table->float('nutrition_facts_vitaminb12')->default(0);
            $table->float('nutrition_facts_vitaminc')->default(0);
            $table->float('nutrition_facts_vitamind')->default(0);
            $table->float('nutrition_facts_vitamine')->default(0);
            $table->float('nutrition_facts_calcium')->default(0);
            $table->float('nutrition_facts_iron')->default(0);
            $table->float('nutrition_facts_magnesium')->default(0);
            $table->float('nutrition_facts_coblamin')->default(0);
            $table->float('nutrition_facts_thiamin')->default(0);
            $table->float('nutrition_facts_riboflavin')->default(0);
            $table->float('nutrition_facts_niacin')->default(0);
            $table->float('nutrition_facts_zinc')->default(0);
            $table->float('nutrition_facts_water')->default(0);
            $table->float('nutrition_facts_ash')->default(0);

            // Allergerns
            // See allergen_product

            $table->nullableTimestamps();
            $table->softDeletes();

        });


    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('products');
    }
}
